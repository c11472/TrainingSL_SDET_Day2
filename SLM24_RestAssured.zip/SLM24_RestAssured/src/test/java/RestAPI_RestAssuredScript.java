import java.io.IOException;

import org.testng.annotations.Test;

import TestScriptsForAPITesting.Testcase_001_GetMethod;

public class RestAPI_RestAssuredScript {
	// Object for the class
	Testcase_001_GetMethod obj = new Testcase_001_GetMethod();

	@Test(priority = 1)
	public void GetTestMethod() throws IOException {
		obj.Get_APITest_Method();

	}

	@Test(priority = 2)
	public void PostTestMethod() {
		obj.Post_APITest_Method();
	}
}
