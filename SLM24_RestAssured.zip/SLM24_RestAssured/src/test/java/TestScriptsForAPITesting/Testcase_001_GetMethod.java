package TestScriptsForAPITesting;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Testcase_001_GetMethod {
	Properties P;
	FileReader FR;

	public static void main(String[] args) throws FileNotFoundException {

	}

	public static void Get_APITest_Method() throws IOException {
		Properties P = new Properties();
		FileReader FR = new FileReader(
				"D:\\WorkspaceJava_Gayatri\\SLM24_RestAssured\\TestInputData\\TestAPIData.properties");
		P.load(FR);
		// Pre req
		String BaseURIGet = P.getProperty("burig");
		RestAssured.baseURI = BaseURIGet;

		String EndPointGet = P.getProperty("epg");
		Response res = RestAssured.get(EndPointGet);

		// RestAssured.post();
		// RestAssured.delete();

		int StatusCode1 = res.getStatusCode();

		System.out.println("The status code for the get - api" + " " + StatusCode1);
		System.out.println(res.getTime());
		System.out.println(res.getBody());

	}

	public static void Post_APITest_Method() {
		String BaseURIPost1 = "https://reqres.in";
		String EndPointPost1 = "/api/users ";
		String APIBody1 = "{\name\":\"morpheus\",\"job\":\"leader\"}";
		int ExpStatusCode = 201;
		Response response = RestAssured.given().contentType(ContentType.JSON).body(APIBody1).post(EndPointPost1);
		// Response response =
		// RestAssured.given().contentType(ContentType.JSON).body(APIBody1).delete("");
		int StatusCodePost = response.getStatusCode();
		// System.out.println(StatusCodePost);

		String headerval = response.getHeader(APIBody1);

		System.out.println(response.getTime());

		int actStatusCode = response.getStatusCode();

		if (ExpStatusCode == actStatusCode) {
			System.out.println("Valid status code generated");// DDT - properties file
		} else {
			System.out.println("Invalid status code");
		}

	}

}
